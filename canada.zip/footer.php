<footer>
<div class ="outer-footer">

   <div class ="footer-left">  
   <h5>Get In Touch</h5>
   <p>P: 1.123.456.789</br>
    F: 1.123.456.789</br>
     Email: DhaliwalFronteries@gmail.com</br>
     <p>
     <a href="#"><img src="fb.png"></a>
     <a href="#"><img src="twiter.png"></a>
     <a href="#"><img src="insta.png"></a>
     <a href="#"><img src="you-tube.png"></a></p>
    
    </p> 
    
    </div>
   <div class ="footer-center">
<h5>Our Location</h5>
<p>
   Dhaliwal Frontiers Inc.</br>
    XYZ  St</br>
    Calgary, AB V3K 4X9</br>
    Weely Hours:</br>
    Open 24/7, 7 days in week
</p>



   </div>

   <div class ="footer-right">
   <h5>Reach Us Here</h5>
   <p>
   <iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d5012.341433136973!2d-113.93343847415775!3d51.086856857514604!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e6!4m3!3m2!1d51.0846507!2d-113.9281242!4m5!1s0x537163449d0a3333%3A0xdcae3cf99c2a9f6b!2s268%20Fresno%20Pl%20NE%2C%20Calgary%2C%20AB%20T1Y%206Y3!3m2!1d51.0897455!2d-113.92965199999999!5e0!3m2!1sen!2sca!4v1614309218277!5m2!1sen!2sca"
       width="270" height="200"
       style="border-radius:10px;"   allowfullscreen="" loading="lazy"></iframe></p>
   
   </div>
   <div class ="copy-right"><p align="center">Copyright &copy; 2021 DhaliwalFrontiers.com </p></div>


   </div>



</footer>
