<head><link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<script>
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
</script>

</head>

<header>

<div class="mobile-container">

<!-- Top Navigation Menu -->
<div class="topnav">
  <a href="index.php" class="active"><img src="log.png"></a>
  <div id="myLinks">
  <a href="index.php">Home</a>
    <a href="about.php">About Us</a>
    <a href="services.php">Our Services</a>
    <a href="contact-us.php">Contact Us</a>
    <a href="career.php">Career</a>

    <a href="blog.php">Blog</a>
  </div>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>



<!-- End smartphone / tablet look -->
</div>


<div class ="logo-nav-container">
<div>
   <div class = "logo" ><a href="index.php"><img src="log.png"></a>
   </div>
   <!--<div class = "header-call-to-action">Call Us : <a href=”tel:+1-877-538-5888″>001-123-4567</a> 

   
   </div>-->

   <div class = "nav-bar" >
   <nav>
    <a href="index.php">Home</a>
    <a href="about.php">About Us</a>
    <a href="services.php">Our Services</a>
    <a href="contact-us.php">Contact Us</a>
    <a href="career.php">Career</a>

    <a href="blog.php">Blog</a>

  </nav>
  </div>
  </div>
  </div>
</header>