<aside>
    <div class="sidebar">
<div class="sidebar-1">
<img src ="side-bar.png"  class="aside-img">
</div>
<div class="sidebar-2">
<p>
<b>Get In Touch For Free Estimate..</b></p>
<div class="sidebar-get-quote" >
<a href="contact-us.php"><button>Get Free Quote</button></a>
</div>
</div>

</div>

</aside>