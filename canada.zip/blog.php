<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </-- stylesheets -->
    <link rel= "stylesheet"  type="text/css" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    
    <title>Contact Us | DhaliwalFrontiers.com</title>
</head>


<body>
    
<div class="site">
    <?php include 'header.php'; ?> 
    <main>
    <div class="inner-page-sub-header">
    <h1>Our Blogs</h1>
    </div>
    <div class="inner-page-content">
    <div class="blog-page">
    <p><h3>Here is our first blog.....</h3>
    <span class ="date">
<?php
echo "" . date("Y/m/d") . "<br>";
?>
<p>Coming Soon......

</p>
</span>
</p>
</div>
    </div>   
<?php include 'aside.php'; ?>





    
    </main>
     
     <?php include 'footer.php'; ?>
  </div>

</body>
</html>