
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </-- stylesheets -->
    <link rel= "stylesheet"  type="text/css" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
    
    <title>Our Services | DhaliwalFrontiers.com</title>
</head>


<body>
    
<div class="site">
    <?php include 'header.php'; ?> 
    <main>
    <div class="inner-page-sub-header">
        <h1>Career</h1>
</div>
<div class="inner-page-content">

<p><h3>Do You want to join our Team. Please send your resume on DhaliwalFrontiers@gmail.com</h3></p>




</div>



<?php include 'aside.php'; ?>





    
    </main>
     
     <?php include 'footer.php'; ?>
  </div>

</body>
</html>